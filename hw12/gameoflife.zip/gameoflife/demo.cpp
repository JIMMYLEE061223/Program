#include <iostream>
#include "Map.hpp"
#include "Player.hpp"

using namespace std;

int rollDice() {
    return (rand()%6) + 1;
}

void PlayerForward(Map& map, Player& player, int numStep) {
    Square *current, *next;
    for (int i=0; i<numStep; i++) {
        current = player.Position();
        next = current->NextSquare();
        player.setPosition(next);
    }
}

int main() {

    srand(time(NULL));

    Map map;
    Player player;

    //Load map from Map.txt and print first ten squares
    map.LoadMap();
    map.CheckMap();
    /*
    Square *tmp = map.StartSquare();
    for (int i=0; i<10; i++) {
      cout << i << ". " << tmp->Description() << endl;
      tmp = tmp->NextSquare();
    }
    cout << endl;
    */

    //Place player to the start square
    Square *Start = map.StartSquare();
    if (Start == NULL) {
        cerr << "Cannot find Start square in the map...." << endl;
        return 1;
    }
    player.setPosition(Start);
    cout << "Player is at: " <<  player.Position()->Description() << endl;

    //Roll a dice and make player foward
    int numStep = rollDice();
    cout << "Player foward " << numStep << " steps!" << endl;
    PlayerForward(map, player, numStep);
    cout << "Player is at: " <<  player.Position()->Description() << endl;
    if(player.Position()->Type()==Square::GetMoney){
        player.EarnMoney(player.Position()->Number());
    }
    cout << "The player now has ";
    cout << player.ComputeTotalValue() << endl;

    //Demo other properties

    //Families
    player.GetMarry();
    player.HaveABaby();
    player.HaveABaby();
    player.GetAPet();
    player.GetAPet();
    cout << player.ComputeTotalValue() << endl;

    //Transport
    player.GetaVehicle(new Car);
    player.ReportValues();
    player.GetaVehicle(new Airplane);
    player.ReportValues();

    //Passport Stamp
    player.GetAStamp(Stamp::Beach);
    player.GetAStamp(Stamp::City);
    player.GetAStamp(Stamp::Snow);
    player.GetAStamp(Stamp::Jungle);
    cout << player.ComputeTotalValue() << endl;

    //House
    Square sq(Square::House, 0, "New House", 1000);
    player.BuyHouse(&sq);
    cout << player.ComputeTotalValue() << endl;

    //Get a Job
    player.GetaJob(new Explorer);
    cout << "My salary is " << player.GetSalary() << endl;

    //Education
    player.GotoCollage();
    //Switch job
    player.GetaJob(new Vet);
    cout << "My salary now is " << player.GetSalary() << endl;
    player.Promote();
    cout << "I got promoted and my salary now is " << player.GetSalary() << endl;

    return 0;
}
