#include <iostream>
#include <string>
#include <fstream>
using namespace std;

    string name,identity;
    string q[3]{"heartrate","bloodpressure","bodyfats"},
           a[3]{"smartwatch","sphygmometer","BodyFatMonitor"};

char endMenu1(){
    string productmodel,purchasedate;
    int repairnumber=2564156,productnumber;
    cin>>productmodel;
    cin>>productnumber;
    cin>>purchasedate;
    cout<<"------------Product repair bill:---------------"<<endl;
    cout<<"Your repair number is  "<<repairnumber<<endl;
    cout<<"Your product model is  "<<productmodel<<endl;
    cout<<"Your purchase date is  "<<purchasedate<<endl;
    cout<<"-----------------------------------------------"<<endl;
    cout<<"It's our responsibility to reapir our products,so we don't charge any fee from you!"<<endl;
    return 'c';
    }
char endMenu2(){
     return 'c';
    }
char endMenu3(){
    string productmodel1,purchasedate1;
    int returnnumber=8942315,productnumber;
    cin>>productmodel1;
    cin>>productnumber;
    cin>>purchasedate1;
    cout<<"Your return number is  "<<returnnumber<<endl;
    return 'c';
    }

char endMenu(){
    char selection3;
    cout<<"If you don't like this,please enter N"<<endl;
    cout<<"if you want to go to the back menu,please enter c."<<endl;
    keyin:cin>>selection3;
    if(selection3=='Y'||selection3=='y'){
        cout<<"Thank you for your purchasing!"<<endl;
        return 0;
    }
    else if(selection3=='n'||selection3=='N'){
        cout<<"Then that's look at the others products"<<endl;
        return 'n';
    }
    else if(selection3=='c'||selection3=='C'){
        return 'c';
    }
    else{
        cout<<"you enter the wrong char"<<endl;
        cout<<"please enter c to go to the home menu:"<<endl;
        goto keyin;
    }
}

int main()
{
    ofstream openfile;
    openfile.open("hw5.txt");
    openfile<<"your whole choice is:"<<endl;
    cout<<"Customers log in:"<<endl<<endl;
    cout<<"Enter your name and identity card"<<endl;
    cin>>name>>identity;
    openfile<<name<<identity<<endl;
    char selection1=1;
    while(selection1!='C' && selection1!='c'){
        cout << "Welcome to our Customer Service Center,the following is home menu.Please choose you option: " << endl;
        cout << "A.Product usage" << endl;
        cout << "B.Product inquiry" << endl;
        cout << "C.Leave system" << endl;
        int selection2;
        cin>>selection1;
        openfile<<selection1<<endl;

        //Product usage
        if(selection1=='a'||selection1=='A'){
            char selection=1;
            while(selection!='c'){

                cout<<"We have three products,which one do you like?"<<endl;
                cout << "1.smartwatch" << endl;
                cout << "2.sphygmometer" << endl;
                cout << "3.BodyFatMonitor" << endl;
                cout<<"please enter 4 to go to the home menu:"<<endl;
                cin>>selection2;
                openfile<<selection2<<endl;
                //Feature selection
                if(selection2==1){
                    cout<<" Our smartwatch have feature that can measure you heartrate,if you want to buy it,please enter Y"<<endl;
                    selection = endMenu();
                }
                if(selection2==2){
                    cout<<" Our sphygmometer have feature that can measure you blood preasure,if you want to buy it,please enter Y"<<endl;
                    selection = endMenu();
                }
                 if(selection2==3){
                    cout<<" Our BodyFatMonitor have feature that can measure you bodyfats,if you want to buy it,please enter Y"<<endl;
                    selection = endMenu();
                }
                 if(selection2==4)
                    { selection = 'c';}
}
        }

    //Product inquiry
        char selection4;
        if(selection1=='B' || selection1=='b'){
                    char selection3='a';
                    while(selection3!='c' && selection3!='C'){
                        cout<<"You need Product repair or Product return?"<<endl;
                        cout<<"W.Product repair"<<endl;
                        cout<<"S.Product return"<<endl;
                        cin>>selection4;
                        openfile<<selection4<<endl;
                if(selection4=='W'||selection4=='w'){
                     cout<<"We will dispatch a repairman to you house and repair the product"<<endl;
                     cout<<"Please fill the product model,product number,purchase date"<<endl;
                     selection3 = endMenu1();
                }
                if(selection4=='S'||selection4=='s'){
                     cout<<"We will recycle the product from you house in two days."<<endl;
                     cout<<"Please fill the product model,product number,purchase date"<<endl;
                     selection3 = endMenu3();
                }
       }
}
}
    openfile.close();
    return 0;
        }




