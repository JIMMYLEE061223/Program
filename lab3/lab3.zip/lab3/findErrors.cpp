// Lab 3 findErrors.cpp
// This program contains many syntax errors and will not compile.
// Fix the errors so that it correctly finds the average of the
// two integers the user enters.
// PUT YOUR NAME HERE.

#include <iostream>
using namespace std;

int main
Int num1, num2,
    double average;

// Input 2 integers
Cout << "Enter two integers separated by one or more spaces: ";
Cin  << num1, num2;

Find and display their average
(num1 + num2) / 2 = average;

Cout << "\nThe average of these 2 numbers is " << average << "endl";

return 0;
