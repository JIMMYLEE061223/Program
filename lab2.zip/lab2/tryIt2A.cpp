// Lab 2 tryIt2A -- Printing constants and variables
#include <iostream>
using namespace std;

int main()
{   int x = 1, y = 3;
    int X = 2, Y = 4;

    cout << "tryIt 2A" <<endl;
    cout << x << y << endl;
    cout << "x" << "y" << endl;
    cout << X << " " << Y << endl;
    cout << 2 * x + y << endl;
    cout << 2 * X + Y << endl;
    //cout << x + 2*y << endl;
    cout << "x = ";
    cout << x;
    cout << " y = ";
    cout << y;

    return 0;
}
