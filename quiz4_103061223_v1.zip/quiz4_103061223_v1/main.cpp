#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <cmath>

using namespace std;

int main()
{
  double guess,r,n,i;
  cout<<"please input n=?"<<endl;
 cin>>n;
 guess=n/2;
   while(abs(guess*guess-n)<0.000001)
           {

      r=n/guess;
      guess=(guess+r)/2;
}
cout<<guess<<endl;
    for(i=0;i<=10;i++)
    {

       r=n/guess;
       guess=(guess+r)/2;



   }
cout<<guess<<endl;


return 0;
}
